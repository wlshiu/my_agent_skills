# career-coach skill for Claude

A no-fluff career discovery skill that helps you excavate your real work history and turn it into usable material — STAR stories, capability maps, career narratives, and direction clarity. Skips the vision board stuff. Just extracts what you've actually done and helps you talk about it.

Built for Claude on [claude.ai](https://claude.ai).

---

## What It Does

- Pulls real STAR stories out of your experience
- Maps your actual skill levels (not what you wish you had)
- Builds a career narrative that connects past → present → future
- Helps you figure out what you actually want vs. what you think you should want

Good for: job searching, interview prep, resume rewrites, impostor syndrome, career pivots.

---

## Installation

### Claude.ai

Requires a Pro, Max, Team, or Enterprise plan with Code Execution enabled.

1. Download or clone this repo
2. Zip the skill folder (the folder containing `SKILL.md`, not just the file itself)
3. Go to **Settings → Features → Skills**
4. Upload the zip
5. The skill is now available across all your conversations

### Claude Code

Skills live in `.claude/skills/` as a directory containing a `SKILL.md` file.

**Global (available in every Claude Code session):**
```bash
mkdir -p ~/.claude/skills/career-coach
cp SKILL.md ~/.claude/skills/career-coach/SKILL.md
```

**Project-specific:**
```bash
mkdir -p .claude/skills/career-coach
cp SKILL.md .claude/skills/career-coach/SKILL.md
```

Claude Code will discover and load it automatically when relevant, or you can invoke it directly with `/career-coach`.

---

## Usage

Just talk to Claude naturally inside the Project. Trigger phrases:

- "Help me figure out what to put on my resume"
- "I need to prep for interviews but don't have good examples"
- "I don't know how to explain what I actually do"
- "Can you run me through career discovery?"

Claude will guide you through the phases: achievement excavation, capability mapping, narrative construction, and direction clarification.

---

## What You'll Get Out

- 5–10 STAR stories you can use in interviews and resume bullets
- An honest skill map (production-ready vs. needs brushup vs. learning)
- A 3–5 sentence career narrative
- Clarity on target roles and your actual competitive advantages